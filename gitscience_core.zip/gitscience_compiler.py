#!/usr/bin/env python3
# -*- coding: utf-8 -*-
""" gitscience_compiler.py — AST-компилятор No-Code формул из Markdown """
import re
import ast
import json
import hashlib
from pathlib import Path
from typing import Dict, Any, List

class FormulaExtractor(ast.NodeVisitor):
    def __init__(self):
        self.is_safe = True

    def visit(self, node):
        if not isinstance(node, (ast.Expression, ast.BinOp, ast.UnaryOp, ast.Name, ast.Constant, ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow)):
            self.is_safe = False
        self.generic_visit(node)

class GitScienceCompiler:
    def __init__(self, output_dir: Path):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def compile_markdown(self, markdown_content: str) -> Dict[str, Any]:
        sha256_hash = hashlib.sha256(markdown_content.encode('utf-8')).hexdigest()
        
        formulas = re.findall(r'([A-Za-z0-9_]+)\s*=\s*([A-Za-z0-9_\s\+\-\*\/\(\)\.]+)', markdown_content)
        
        compiled_formulas = []
        for name, expr in formulas:
            compiled_formulas.append({"name": name.strip(), "expression": expr.strip()})

        calc_code = f"""# Автоматически сгенерированный калькулятор GitScience
FORMULAS = {json.dumps(compiled_formulas, indent=4)}

def calculate(params):
    results = {{}}
    for f in FORMULAS:
        try:
            results[f['name']] = eval(f['expression'], {{"__builtins__": None}}, params)
        except Exception as e:
            results[f['name']] = f"Error: {{e}}"
    return results
"""
        calc_path = self.output_dir / "compiled_calculator.py"
        calc_path.write_text(calc_code, encoding="utf-8")

        dpid = f"dPID-2026-{sha256_hash[:8]}"
        return {
            "hash": sha256_hash,
            "dpid": dpid,
            "formulas_found": len(compiled_formulas),
            "calculator_path": str(calc_path)
        }